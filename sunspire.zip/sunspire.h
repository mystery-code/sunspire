/////////////////// SUNSPIRE.H ///////////////////

text title="   Sunspire - Inspirational Resources",
  title_icon_file="media/image/sunspire";
IMAGE title_icon;

FONT small_font, quote_font;
text small_font_name="WRITE_S",
  quote_font_name="ROMAN_XLB";

int SCENE_HOME=0, SCENE_QUOTE=1, scene=0;

text get_quote_file();
int get_quote_file_index();
          
////////////////////// TOOLBAR ///////////////////

TOOLBAR main_toolbar;

#define N_TOOLBAR_ICONS 7

text toolbar_icon_files[N_TOOLBAR_ICONS]={
  "home", "arrow_l", "arrow_r",
  "note_left", "note_right",
  "random", "copya"
};

text toolbar_captions[N_TOOLBAR_ICONS]={
  "Home (Key: HOME)",
  "Previous File (Key: DOWN)",
  "Next File (Key: UP)",
  "Previous Quote (Key: LEFT)",
  "Next Quote (Key: RIGHT)",
  "Random Quote (Key: R)",
  "Copy Quote (Key: C)"
};

///////////////// PICTURE ICONS //////////////////

int picture_select=0;

#define PICTURE_ICON_W 96
#define PICTURE_ICON_H 128
#define PICTURE_ICON_INSET_X 8
#define PICTURE_ICON_INSET_Y 8
#define PICTURE_ICON_ARRAY_X 223
#define PICTURE_ICON_ARRAY_Y 92
#define PICTURE_ICON_ARRAY_W 8
#define PICTURE_ICON_ARRAY_H 4
#define N_PICTURE_ICONS \
  (PICTURE_ICON_ARRAY_W*PICTURE_ICON_ARRAY_H)

IMAGE picture_icon_images[N_PICTURE_ICONS];

text picture_icon_files[N_PICTURE_ICONS]={
  "quote", "love", "gandhi", "albert_einstein",
  "african", "indian", "chinese", "socrates",
  "tony_robbins", "les_brown", "jim_rohn",
  "evan_carmichael", "grant_cardone", "eric_thomas",
  "earl_nightingale", "zig_ziglar", "forbes",
  "success_magazine", "addicted2success", "secret",
  "bill_gates", "steve_jobs", "elon_musk",
  "jordan_peterson", "sacred_texts", "buddha",
  "jesus", "td_jakes", "martin_luther_king",
  "abraham_lincoln", "malcolm_x", "deepak_chopra"
};

int load_picture_icons() {
  int i, n=N_PICTURE_ICONS;
  char name[128];
  text path="media/image/";
  for (i=0; i<n; i++) {
    print(name, "%s%s", path, picture_icon_files[i]);
    if (!load_bmp(&picture_icon_images[i], name))
      return 0;
  }
  return 1;
}

void draw_picture_icons() {
  int i, x, y,
    mix=PICTURE_ICON_ARRAY_X, miy=PICTURE_ICON_ARRAY_Y,
    iw=PICTURE_ICON_W, ih=PICTURE_ICON_H,
    ix=PICTURE_ICON_INSET_X, iy=PICTURE_ICON_INSET_Y,
    miw=PICTURE_ICON_ARRAY_W, mih=PICTURE_ICON_ARRAY_H;
  IMAGE *ip;
  for (y=0, i=0; y<mih; y++) {
    for (x=0; x<miw; x++, i++) {
      ip=&picture_icon_images[i];
      move_image(ip, mix+(x*(iw+4)),
        miy+(y*(ih+4)));
      if (select_image(ip)) {
        if (mouse_1)
          scene=SCENE_QUOTE;
        draw_image_mix(ip, 0xDFDFFF, 192);
        draw_box(ip->x, ip->y, ip->w, ip->h,
          WHITE, 0);
        draw_box(ip->x-1, ip->y-1, ip->w+2, ip->h+2,
          WHITE, 0);
        draw_box(ip->x-2, ip->y-2, ip->w+3, ip->h+3,
          WHITE, 0);
        picture_select=i;
      }
      else {
        draw_image(ip);
        draw_box(ip->x, ip->y, ip->w, ip->h,
          WHITE, 0);
      }
    }
  }
}

///////////////// PROFILE ICONS /////////////////

#define PROFILE_ICON_ARRAY_X 7
#define PROFILE_ICON_ARRAY_Y 300+32
#define PROFILE_ICON_ARRAY_W 4
#define PROFILE_ICON_ARRAY_H 2
#define N_PROFILE_ICONS \
  (PROFILE_ICON_ARRAY_W*PROFILE_ICON_ARRAY_H)

#define PROFILE_ICON_W 48
#define PROFILE_ICON_H 48
#define PROFILE_ICON_INSET_X 2
#define PROFILE_ICON_INSET_Y 2

int profile_select=-1;

IMAGE profile_icon_images[N_PROFILE_ICONS];

text profile_icon_files[N_PROFILE_ICONS]={
  "note", "earth", "google", "youtube",
  "wikipedia", "facebook", "twitter", "instagram"
};

text wikipedia_site="en.wikipedia.org/wiki/",
  facebook_site="www.facebook.com/",
  twitter_site="www.twitter.com/",
  instagram_site="www.instagram.com/";

object {
  text name, title,
    quotes, site, google, youtube,
    wikipedia, facebook, twitter, instagram;
} PROFILE_ICON;

PROFILE_ICON profile_icons[N_PICTURE_ICONS]={
  { "Random", "Quotes", "random", 0,
    "inspirational quotes", 0, 0, 0, 0, 0  },
  { "Love", "Quotes about Love", 0,
    0, 0, 0, 0, 0, 0, 0 },
  { "Mahatma Gandhi", "Spiritual Leader",
    "gandhi", "www.mkgandhi.org", "google",
    "youtube", "Mahatma_Gandhi",
    "MahatmaGandhiii", "MahatmaGandhiQuotes",
    "mahatmagandhi.ve/" },
  { "Albert Einstein", "Intellectual\r\nPhysicist",
    "albert_einstein", "http://www.albert-einstein.org/",
    "google", "youtube",
    "Albert_Einstein", "AlbertEinstein",
    "AlbertEinstein", "alberteinstein" },
  { "African Proverbs", "Quotes", "african", 0, "google",
    0, 0, 0, 0, 0  },
  { "Indian Proverbs", "Quotes", "indian", 0, "google",
    0, 0, 0, 0, 0  },
  { "Chinese Proverbs", "Quotes", "chinese", 0, "google",
    0, 0, 0, 0, 0  },
  { "Ancient", "Ancient Philosophers,\r\nSocrates,\r\n" \
    "Aristotle,\r\nPlato,\r\nPythagoras",
    "ancient_philosophers", 0, "quotes ancient philosophers",
    0, 0, 0, 0, 0  },
  { "Tony Robbins", "Author,\r\nEntrepreneur,\r\n" \
    "Life Coach,\r\nMotivational Speaker,\r\nPhilanthropist",
    "tony_robbins", "www.tonyrobbins.com", "google",
    "youtube", "Tony_Robbins", "TonyRobbins",
    "TonyRobbins", "tonyrobbins" },
  { "Les Brown", "Author,\r\n" \
    "Motivational Speaker,\r\nRadio DJ,\r\nBusinessman",
    "les_brown", "www.lesbrown.com", "google",
    "youtube", "Les_Brown_(speaker)", "thelesbrown",
    "LesBrown77", "thelesbrown" },
  { "Jim Rohn", "Author,\r\nEntrepreneur,\r\n" \
    "Motivational Speaker",
    "jim_rohn", "www.jimrohn.com", "google",
    "youtube", "Jim_Rohn", "OfficialJimRohn",
    "OfficialJimRohn", "jimrohn.official" },
  { "Evan Carmichael", "Author,\r\n" \
    "Motivator,\r\nEntrepreneur",
    "evan_carmichael", "www.evancarmichael.com", "google",
    "youtube", 0, "EvanCarmichaelcom",
    "EvanCarmichael", "evancarmichael" },
  { "Grant Cardone", "Author,\r\n" \
    "Motivational Speaker,\r\nSalesperson",
    "grant_cardone", "www.grantcardone.com", "google",
    "youtube", 0, "grantcardonefan",
    "GrantCardone", "grantcardone" },
  { "Eric Thomas", "Author,\r\n" \
    "Motivational Speaker,\r\nMinister",
    "eric_thomas", "www.etinspires.com", "google",
    "youtube", "Eric_Thomas_(motivational_speaker)",
    "Ericthomasbtc", "etthehiphoppreacher",
    "etthehiphoppreacher" },
  { "Earl Nightingale", "Author,\r\n" \
    "Motivational Speaker", "earl_nightingale",
    "www.earlnightingale.com/Home_Page.html", "google",
    "youtube", "Earl_Nightingale",
    "EarlNightingale", "NightingaleEarl",
    "earl.nightingale" },
  { "Zig Ziglar", "Author,\r\n" \
    "Motivational Speaker,\r\nSalesman",
    "zig_ziglar", "www.ziglar.com", "google",
    "youtube", "Zig_Ziglar",
    "ZigZiglar", "TheZigZiglar",
    "thezigziglar" },
  { "Forbes", "Magazine,\r\nWorld's Richest", 0,
    "www.forbes.com", "google", "youtube",
    0, "forbes", "Forbes", "forbes" },
  { "Success", "Magazine", 0, "www.success.com",
    "google", "youtube", 0, "SUCCESSmagazine",
    "successmagazine", "successmagazine" },
  { "Addicted2Success", "Site", 0,
    "https://addicted2success.com/", 0, 0, 0,
    "Addicted2SuccessDotCom", "Addictd2Success",
    "addicted2success" },
  { "The Secret", "Movie/Book", 0,
    "https://www.thesecret.tv/", "google",
    "youtube", 0, "thesecret", "thesecret", "ilovethesecret" },
  { "Bill Gates", "Businessman,\r\nInvestor,\r\nAuthor,\r\n" \
    "Philanthropist", 0,
    "https://www.gatesnotes.com/", "google",
    "youtube", "Bill_Gates", "BillGates", "BillGates",
    "thisisbillgates" },
  { "Steve Jobs", "Businessman,\r\nInvestor,\r\nAuthor",
    0, "https://allaboutstevejobs.com/", "google",
    "youtube", "Steve_Jobs", "SteveJobsMemorial",
    "SteveJobsFeed", "steve_paul_jobs" },
  { "Elon Musk", "Entrepreneur,\r\nEngineer", "elon_musk",
    "https://www.tesla.com/elon-musk", "google",
    "youtube", "Elon_Musk", 0, "elonmusk", "elonmusk" },
  { "Jordan Peterson", "Psychologist", "jordan_peterson",
    "https://www.jordanbpeterson.com/", "google",
    "youtube", "Jordan_Peterson", "drjordanpeterson",
    "jordanbpeterson", "drjordanpeterson" },
  { "Sacred Texts", "Religious Archives", 0,
    "https://www.sacred-texts.com/", "google",
    "youtube", 0, "internetsacredtextarchive",
    "sacredtexts", 0 },
  { "Buddha", "Quotes", "buddha", "https://tinybuddha.com/",
    "google", "youtube", "Gautama_Buddha",
    "tinybuddha", "tinybuddha", "tinybuddhaofficial" },
  { "Christian", "Quotes", "christian", "https://www.jesussite.com/",
    "google", "youtube", "Jesus", 0, 0, 0 },
  { "TD Jakes", "Author,\r\nChristian Preacher,\r\nBusinessman", "td_jakes",
    "www.tdjakes.org/", "google", "youtube",
    "T._D._Jakes", "bishopjakes", "BishopJakes", "bishopjakes" },
  { "Martin LK Jr", "Martin Luther King Jr,\r\nActivist,\r\n" \
    "Minister,\r\nSpeaker", "martin_luther_king_jr",
    0, "google", "youtube", "Martin_Luther_King_Jr.",
    "MartinLutherKingJr", "mlkquote_files", "thekingcenter" },
  { "Abraham Lincoln", "Lawyer,\r\nPolitician,\r\nAgainst Slavery",    
    "abraham_lincoln", "google", "google", "youtube",
    "Abraham_Lincoln", "PresidentLincoln", "Abe_Lincoln",
    "abraham._lincoln" },
  { "Malcolm X", "Minister, Activist, Speaker", "malcolm_x",
    "https://www.malcolmx.com/", "google", "youtube",
    "Malcolm_X", "MalcolmXQuotes", "malcolm___x", "malcolmxlegacy" },
  { "Deepak Chopra", "Quotes", "deepak_chopra",
    "https://www.deepakchopra.com/", "google",
    "youtube", "Deepak_Chopra", "DeepakChopra", "DeepakChopra",
    "deepakchopra" }
};

int load_profile_icons() {
  int i, n=N_PROFILE_ICONS;
  char name[128];
  text path="media/icon/48/";
  for (i=0; i<n; i++) {
    print(name, "%s%s", path, profile_icon_files[i]);
    if (!load_bmp(&profile_icon_images[i], name))
      return 0;
  }
  return 1;
}

int profile_select=0, profile_click=0;
char profile_link[256];

void draw_profile_icons() {
  int i, x, y,
    mix=PROFILE_ICON_ARRAY_X, miy=PROFILE_ICON_ARRAY_Y,
    iw=PROFILE_ICON_W, ih=PROFILE_ICON_H,
    ix=PROFILE_ICON_INSET_X, iy=PROFILE_ICON_INSET_Y,
    miw=PROFILE_ICON_ARRAY_W, mih=PROFILE_ICON_ARRAY_H;
  IMAGE *ip, image;
  PROFILE_ICON *nip;
  char caption[128], link[512];
  BOX box;
  int cx, cy, enable, select;
  profile_select=0, profile_click=0;
  for (y=0, i=0; y<mih; y++) {
    for (x=0; x<miw; x++, i++) {
      ip=&profile_icon_images[i];
      nip=&profile_icons[picture_select];
      cx=700, cy=40;
      enable=0, select=0;
      caption[0]=0, link[0]=0;
      if (i==0 and nip->quotes) {
        print(link, "quote/%s.txt", nip->quotes);
        print(caption, "Open: %s", link);
        select='q';
      }
      else if (i==1 and nip->site) {
        text_copy(link, nip->site);
        text_copy(caption, nip->site);
        select='s';
      }
      else if (i==2 and nip->google) {
        text_copy(caption, "Google");
        select='g';
      }
      else if (i==3 and nip->youtube) {
        text_copy(caption, "Youtube");
        select='y';
      }
      else if (i==4 and nip->wikipedia) {
        text_copy(link, nip->wikipedia);
        print(caption, "%s%s",
          wikipedia_site, nip->wikipedia);
        select='w';
      }
      else if (i==5 and nip->facebook) {
        text_copy(link, nip->facebook);
        print(caption, "%s%s",
          facebook_site, nip->facebook);
        select='f';
      }
      else if (i==6 and nip->twitter) {
        text_copy(link, nip->twitter);
        print(caption, "%s%s",
          twitter_site, nip->twitter);
        select='t';
      }
      else if (i==7 and nip->instagram) {
        text_copy(link, nip->instagram);
        print(caption, "%s%s",
          instagram_site, nip->instagram);
        select='i';
      }
      if (link[0] or caption[0])
        enable=1;
      set_font_color(WHITE);
      if (link[0])
        set_font_color(BLUE);
      move_image(ip, mix+(x*(iw+4)),
        miy+(y*(ih+4)));
      if (select_image(ip) and enable) {
        get_image_box(ip, &box);
        box.x-=2, box.y-=2, box.w+=4, box.h+=4;
        draw_shade(&box, 'v', GRAY75, WHITE);
        draw_outline(&box, WHITE);
        draw_image_t(ip);
        text t=caption;
        int w=text_w(t)+font.w;
        BOX b={ 600, 53, w, font.h };
        draw_text_c(t, &b);
        set_font_color(WHITE);
        draw_text_v("Links disabled currently", 440, 5);
        if (mouse_1) {
          if (link[0])
            text_replace_c(link, '/', '\\');
          // if (select=='q')
          //  ShellExecuteP(0, "open", link, 0, 0, 3);
          profile_select=select;
          text_copy(profile_link, link);
        }
      }
      else {
        if (enable)
          draw_image_t(ip);
        else
          draw_image_disable(ip);
      }
    }
  }
  // profile_select=select;
  // text_copy(profile_link, link);
  
  ip=&picture_icon_images[picture_select];
  ip->x=13, ip->y=title_box.h+5+32;
  move_image(ip, ip->x, ip->y);
  draw_image_x2(ip);
  draw_box(ip->x, ip->y,
    ip->w*2, ip->h*2, WHITE, 0);
}

void draw_profile() {
  text p;
  char t[256];
  draw_box(0, title_box.h+1, 218,
    screen_h-title_box.h-4, WHITE, 0);
  draw_profile_icons();
  set_font_c(&main_font, WHITE);
  text_copy(t, profile_icons[picture_select].name);
  BOX box={ 8, title_box.h+8, 96*2+11, font.h };
  draw_text_c(t, &box);
  p=profile_icons[picture_select].title;
  if (p) {
    text_copy(t, p);
    set_box(&box, 8, 440, 96*2+11, font.h*4);
    draw_text_c(t, &box);
  }
}

///////////////////// QUOTES /////////////////////

#define N_QUOTE_FILES 26

// quote_files and names. all characters must be
// ASCII 7BIT for custom fonts. if you paste new
// quotes inside these files, "search replace"
// unicode characters like '",-... with 7BIT
// equivelants. many web sites use special
// characters not available on standard keyboards

text quote_files[N_QUOTE_FILES],
  quote_filenames[N_QUOTE_FILES]={
  "abraham_lincoln", "african", "albert_einstein",
  "ancient_philosophers", "barack_obama", "buddha",
  "chinese", "christian", "deepak_chopra",
  "earl_nightingale", "elon_musk", "eric_thomas",
  "evan_carmichael", "gandhi", "grant_cardone",
  "indian", "jim_rohn", "jordan_peterson",
  "keywords", "les_brown", "malcolm_x",
  "martin_luther_king_jr", "random",
  "td_jakes", "tony_robbins", "zig_ziglar"
};

// for each quote file: number of and current
// quote index. example: for first quote file
// (index 0 = "abraham_lincoln"), quote_files_n[0]
// is the number of, and quote_indices[0]
// is the current quote index

int quote_files_n[N_QUOTE_FILES],
  quote_indices[N_QUOTE_FILES];

// load quote files to quote_files[] array. get
// number of lines for each file

int load_quotes() {
  int i;
  char name[256];
  for (i=0; i<N_QUOTE_FILES; i++) {
    print(name, "quote/%s.txt", quote_filenames[i]);
    if (!(quote_files[i]=load_text(name)))
      return 0;
    quote_files_n[i]=text_count_lines(quote_files[i])-1;
  }
  return 1;
}

// get quote_files index that corresponds
// to picture_select or -1 if none

int get_quote_file_index() {
  int i;
  text p;
  p=profile_icons[picture_select].quotes;
  if (!p)
    return -1;
  for (i=0; i<N_PICTURE_ICONS; i++)
    if (text_equal(p, quote_filenames[i]))
      return i;
  return -1;
}

// get quote_files address that corresponds
// to picture_select or 0 if none

text get_quote_file() {
  int i=get_quote_file_index();
  if (i==-1)
    return 0;
  return quote_files[i];
}

BOX big_quote_box={ 225, 100, 791, 515 };

void draw_quote() {
  int i;
  char quote[1024], t[96];
  text p;
  BOX box;
  p=get_quote_file();
  if (p) {
    i=get_quote_file_index();
    text_get_line(quote, p, quote_indices[i]);
    draw_text_c(quote, &big_quote_box);
    set_box(&box, 222, screen_h-63, 797, 60);
    draw_outline(&box, WHITE);
    print(t, "%s. Quote %d of %d",
      profile_icons[picture_select].name,
      quote_indices[i], quote_files_n[i]);
    box.y+=10;
    draw_text_c(t, &box);
  }
}

// load/save quote indices. when program ends,
// current indices will be saved to binary file
// for next startup. the reason for this is to
// save previous quote indices when program
// ends, and not restart at index 0 everytime.
// some files contain 100s of quotes (separated
// with returns: \r\n)

text indices_filename="quote/indices.bin";

// create quote indices.bin

int save_quote_indices() {
  int i;
  if (!create_file(indices_filename))
    return 0;
  for (i=0; i<N_QUOTE_FILES; i++)
    write_4(quote_indices[i]);
  close_file();
  return 1;
}

// create initial indices.bin containing all
// 32BIT zero indices (N_QUOTE_FILES*4 bytes)
// for each file (first is "abraham_lincoln",
// last is "zig_ziglar")

int create_quote_indices() {
  int i;
  for (i=0; i<N_QUOTE_FILES; i++)
    quote_indices[i]=0;
  if (!save_quote_indices())
    return 0;
  return 1;
}

// when program begins, load previous quote
// indices from file. if doesn't exist, create.
// to reset all, before every release,
// delete indices.bin

int load_quote_indices() {
  int i;
  if (!open_file(indices_filename)) {
    create_quote_indices();
    return 1;
  }
  for (i=0; i<N_QUOTE_FILES; i++)
    quote_indices[i]=read_4();
  close_file();
  return 1;
}

// main toolbar functions...

void draw_main_toolbar() {
  TOOLBAR *tb=&main_toolbar;
  draw_toolbar(tb);
  if (tb->select!=-1) {
    text t=toolbar_captions[tb->select];
    int w=text_w(t)+font.w;
    BOX b={ 600, 53, w, font.h };
    draw_text_c(t, &b);
  }
}

// toolbar icon events

void go_home() {
  scene=SCENE_HOME;
}

void next_file() {
  if (picture_select<N_PICTURE_ICONS-1)
    picture_select++;
  else
    picture_select=0;
}

void previous_file() {
  if (picture_select>0)
    picture_select--;
  else
    picture_select=N_PICTURE_ICONS-1;
}

void next_quote() {
  int i=get_quote_file_index();
  if (quote_indices[i]<quote_files_n[i])
    quote_indices[i]++;
  else
    quote_indices[i]=0;
}

void previous_quote() {
  int i=get_quote_file_index();
  if (quote_indices[i]>0)
    quote_indices[i]--;
  else
    quote_indices[i]=quote_files_n[i]-1;
}

void random_quote() {
  int i=get_quote_file_index();
  quote_indices[i]=random_n(0, quote_files_n[i]-1);
}

void copy_quote() {
  char quote[1024];
  int i=get_quote_file_index();
  text_get_line(quote,
    quote_files[i], quote_indices[i]);
  set_clipboard_text(quote);
}