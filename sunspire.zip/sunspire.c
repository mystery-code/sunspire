// "SUNSPIRE - INSPIRATIONAL RESOURCES".
// BY MYSTERISOFT, 2019. INITIAL RELEASE.
// VERSION 0. SEE SUNSPIRE.H

#define INTERFACE
#define EXIT

#include "ez.h"
#include "sunspire.h"

event_create
  set_title(title);
  set_screen_color(BLACK);
  create_screen(1024, 620);
  set_font_folder("media/font");
  if (!load_font(&quote_font, quote_font_name))
    return 0;
  if (!load_bmp(&title_icon, title_icon_file))
    return 0;
  create_toolbar(&main_toolbar, 0, 220,
    37, N_TOOLBAR_ICONS);
  set_toolbar_folder("media/icon/48");
  if (!load_toolbar(&main_toolbar,
    toolbar_icon_files))
    return 0;
  if (!load_picture_icons())
    return 0;
  if (!load_profile_icons())
    return 0;
  if (!load_quotes())
    return 0;
  load_quote_indices();
ende

event_draw
  clear_screen(BLACK);
  draw_box(0, 0, screen_w-1, screen_h-1, WHITE, 0);
  set_font_c(&main_font, WHITE);
  draw_title();
  move_image(&title_icon, 4, 4);
  draw_image_outline(&title_icon, WHITE);
  draw_main_toolbar();
  draw_profile();
  if (scene==SCENE_HOME)
    draw_picture_icons();
  else if (scene==SCENE_QUOTE) {
    set_font_c(&quote_font, WHITE);
    draw_quote();
  }
ende

event_input
  int i;
  input_title();
  if (event_key) {
    if (key==VK_HOME)
      go_home();
    else if (key==K_DOWN)
      previous_file();
    else if (key==K_UP)
      next_file();
    else if (key==K_LEFT)
      previous_quote();
    else if (key==K_RIGHT)
      next_quote();
    else if (key=='C')
      copy_quote();
    else if (key=='R')
      random_quote();
    redraw();
  }
  if (event_mouse) {
    if (mouse_type=='r') {
      i=main_toolbar.select;
      if (i==0)
        go_home();
      else if (i==1)
        previous_file();
      else if (i==2)
        next_file();
      else if (i==3)
        previous_quote();
      else if (i==4)
        next_quote();
      else if (i==5)
        random_quote();
      else if (i==6)
        copy_quote();
    }
    redraw();
  }
ende

event_exit
  save_quote_indices();
ende